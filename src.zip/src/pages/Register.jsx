import React, { useState , useRef} from 'react'
import { http } from '../axios';

import '../index.css'
import { Navigate } from 'react-router-dom';

function Register() {
    const usernameRef = useRef();
    const passwordRef = useRef();

    function handleRegister(e) {
        e.preventDefault();

        let user = {
            username : usernameRef.current.value,
            password : passwordRef.current.value
        }

        http.post("/auth/register", user ,{
            headers: {
                'Content-Type' : "application/json"

            }
        })
        .then(response => {
            if (response.status == 200) {
                Navigate ('./login')
            }

        })
        .catch(error => {
            alert(error.message);
        })
        .finally(function () {
            usernameRef('');
            passwordRef('');

        })        
    }


  return (
    <form>
        <input ref={usernameRef} type="text" placeholder='enter username' />
        <input ref={passwordRef} type="password" placeholder='enter password' />

        <button onClick={handleRegister}>Register</button>
    </form>
)
}

export default Register