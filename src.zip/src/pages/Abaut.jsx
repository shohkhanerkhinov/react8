import React from 'react'

function Abaut() {
  return (
    <div>Abaut</div>
  )
}

export default Abaut